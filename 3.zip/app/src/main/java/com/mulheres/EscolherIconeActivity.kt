package com.mulheres

import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button

import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class EscolherIconeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // =====================================================
        // FULLSCREEN
        // =====================================================

        WindowCompat.setDecorFitsSystemWindows(window, false)

        val controller = WindowInsetsControllerCompat(
            window,
            window.decorView
        )

        controller.hide(WindowInsetsCompat.Type.systemBars())

        controller.systemBarsBehavior =
            WindowInsetsControllerCompat
                .BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        controller.isAppearanceLightStatusBars = false
        controller.isAppearanceLightNavigationBars = false

        window.statusBarColor =
            android.graphics.Color.TRANSPARENT

        window.navigationBarColor =
            android.graphics.Color.TRANSPARENT

        if (android.os.Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
        }

        setContentView(R.layout.activity_escolher_icone)

        val raiz = findViewById<View>(
            android.R.id.content
        )

        aplicarFonte(raiz)

        // =====================================================
        // BOTÕES
        // =====================================================

        findViewById<Button>(R.id.btnIconeOriginal)
            .setOnClickListener {
                trocarParaOriginal()
            }

        findViewById<Button>(R.id.btnIcone1)
            .setOnClickListener {
                trocarParaIcone1()
            }

        findViewById<Button>(R.id.btnIcone2)
            .setOnClickListener {
                trocarParaIcone2()
            }

        findViewById<Button>(R.id.btnIcone3)
            .setOnClickListener {
                trocarParaIcone3()
            }
    }

    // =========================================================
    // TROCAR ÍCONE
    // =========================================================

    private fun trocarPara(nomeAtivo: String) {

        val pm = packageManager

        val icons = listOf(
            "com.mulheres.IconeOriginal",
            "com.mulheres.Icone1",
            "com.mulheres.Icone2",
            "com.mulheres.Icone3"
        )

        icons.forEach { nome ->

            val component = ComponentName(
                this,
                nome
            )

            val estado =
                if (nome == nomeAtivo) {

                    PackageManager
                        .COMPONENT_ENABLED_STATE_ENABLED

                } else {

                    PackageManager
                        .COMPONENT_ENABLED_STATE_DISABLED
                }

            pm.setComponentEnabledSetting(
                component,
                estado,
                PackageManager.DONT_KILL_APP
            )
        }
    }

    // =========================================================
    // MANDAR MENSAGEM PARA A MAINACTIVITY
    // =========================================================

    private fun avisarJavaScript(pagina: String) {

        val intent = Intent(
            this,
            MainActivity::class.java
        )

        intent.putExtra(
            "PAGINA_JS",
            pagina
        )

        intent.addFlags(
            Intent.FLAG_ACTIVITY_CLEAR_TOP or
            Intent.FLAG_ACTIVITY_SINGLE_TOP
        )

        startActivity(intent)

        finish()
    }

    // =========================================================
    // ÍCONE ORIGINAL
    // =========================================================

    private fun trocarParaOriginal() {

        trocarPara(
            "com.mulheres.IconeOriginal"
        )

        // Original = index1
        avisarJavaScript("index1")
    }

    // =========================================================
    // ÍCONE 1
    // =========================================================

    private fun trocarParaIcone1() {

        trocarPara(
            "com.mulheres.Icone1"
        )

        // Ícone 1 = index1
        avisarJavaScript("index1")
    }

    // =========================================================
    // ÍCONE 2
    // =========================================================

    private fun trocarParaIcone2() {

        trocarPara(
            "com.mulheres.Icone2"
        )

        // Ícone 2 = index1
        avisarJavaScript("index1")
    }

    // =========================================================
    // ÍCONE 3
    // =========================================================

    private fun trocarParaIcone3() {

        trocarPara(
            "com.mulheres.Icone3"
        )

        // Ícone 3 = index11
        avisarJavaScript("index11")
    }

    // =========================================================
    // FONTE
    // =========================================================

    private fun aplicarFonte(view: View) {

        val fonte = Typeface.createFromAsset(
            assets,
            "font.ttf"
        )

        if (view is android.widget.TextView) {
            view.typeface = fonte
        }

        if (view is ViewGroup) {

            for (i in 0 until view.childCount) {

                aplicarFonte(
                    view.getChildAt(i)
                )
            }
        }
    }
}