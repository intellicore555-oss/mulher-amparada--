package com.mulheres

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat

import java.io.File

class GravarActivity : AppCompatActivity() {

    private lateinit var btnRecord: ImageView
    private lateinit var list: LinearLayout
    private lateinit var cripto: Cripto

    private var recorder: MediaRecorder? = null
    private var player: MediaPlayer? = null

    private var currentFile: String = ""
    private var recording = false

    // Arquivo temporário usado somente durante a reprodução
    private var currentTempFile: File? = null


    // =========================================================
    // ON CREATE
    // =========================================================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

window.addFlags(
        WindowManager.LayoutParams.FLAG_SECURE
    )
        // =====================================================
        // BARRAS TRANSPARENTES
        // =====================================================

        WindowCompat.setDecorFitsSystemWindows(
            window,
            false
        )

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isNavigationBarContrastEnforced = false
        }

        val controller = WindowInsetsControllerCompat(
            window,
            window.decorView
        )

        controller.isAppearanceLightStatusBars = false
        controller.isAppearanceLightNavigationBars = false


        // =====================================================
        // LAYOUT
        // =====================================================

        setContentView(
            R.layout.activity_gravar
        )


        // =====================================================
        // CRIPTOGRAFIA
        // =====================================================

        cripto = Cripto(this)


        // =====================================================
        // FONTE
        // =====================================================

        val raiz = findViewById<View>(
            android.R.id.content
        )

        aplicarFonte(raiz)


        // =====================================================
        // COMPONENTES
        // =====================================================

        btnRecord = findViewById(
            R.id.btnRecord
        )

        list = findViewById(
            R.id.list
        )


        // =====================================================
        // CARREGAR ÁUDIOS JÁ SALVOS
        // =====================================================

        carregarGravacoes()


        // =====================================================
        // PERMISSÃO
        // =====================================================

        checkPermission()


        // =====================================================
        // BOTÃO DE GRAVAÇÃO
        // =====================================================

        btnRecord.setOnClickListener {

            if (recording) {

                stopRecord()

            } else {

                startRecord()
            }
        }
    }


    // =========================================================
    // CARREGAR GRAVAÇÕES SALVAS
    // =========================================================

    private fun carregarGravacoes() {

        val dir =
            getExternalFilesDir(null)
                ?: return

        val arquivos =
            dir.listFiles()
                ?: return


        arquivos
            .filter {

                it.isFile &&
                it.extension.equals(
                    "enc",
                    ignoreCase = true
                )
            }
            .sortedBy {

                it.lastModified()
            }
            .forEach {

                addToList(
                    it.absolutePath
                )
            }
    }


    // =========================================================
    // BOTÃO VOLTAR
    // =========================================================

    override fun onBackPressed() {

        finish()
    }


    // =========================================================
    // PERMISSÃO
    // =========================================================

    private fun checkPermission() {

        if (
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) != PackageManager.PERMISSION_GRANTED
        ) {

            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.RECORD_AUDIO
                ),
                1
            )
        }
    }


    // =========================================================
    // INICIAR GRAVAÇÃO
    // =========================================================

    private fun startRecord() {

        try {

            val dir =
                getExternalFilesDir(null)
                    ?: return


            // =================================================
            // ARQUIVO TEMPORÁRIO DA GRAVAÇÃO
            // =================================================

            currentFile =
                "${dir.absolutePath}/rec_${System.currentTimeMillis()}.3gp"


            recorder =
                MediaRecorder().apply {

                    setAudioSource(
                        MediaRecorder.AudioSource.MIC
                    )

                    setOutputFormat(
                        MediaRecorder.OutputFormat.THREE_GPP
                    )

                    setAudioEncoder(
                        MediaRecorder.AudioEncoder.AMR_NB
                    )

                    setOutputFile(
                        currentFile
                    )

                    prepare()

                    start()
                }


            recording = true


            btnRecord.setImageResource(
                R.drawable.mic1
            )

        } catch (e: Exception) {

            e.printStackTrace()

            recorder?.release()

            recorder = null

            recording = false

            btnRecord.setImageResource(
                R.drawable.mic
            )
        }
    }


    // =========================================================
    // PARAR GRAVAÇÃO
    // =========================================================

    private fun stopRecord() {

        try {

            // =================================================
            // PARAR MEDIARECORDER
            // =================================================

            recorder?.apply {

                stop()

                release()
            }

            recorder = null

            recording = false


            btnRecord.setImageResource(
                R.drawable.mic
            )


            // =================================================
            // ARQUIVO ORIGINAL .3GP
            // =================================================

            val original =
                File(currentFile)


            if (!original.exists()) {

                currentFile = ""

                return
            }


            // =================================================
            // ARQUIVO CRIPTOGRAFADO .ENC
            // =================================================

            val criptografado =
                File(
                    original.parent,
                    original.nameWithoutExtension + ".enc"
                )


            // =================================================
            // CRIPTOGRAFAR
            // =================================================

            cripto.criptografarArquivo(
                original,
                criptografado
            )


            // =================================================
            // APAGAR SOMENTE O .3GP ORIGINAL
            // =================================================

            if (original.exists()) {

                original.delete()
            }


            // =================================================
            // VERIFICAR SE O .ENC FOI CRIADO
            // =================================================

            if (criptografado.exists()) {

                addToList(
                    criptografado.absolutePath
                )
            }


            // =================================================
            // LIMPAR REFERÊNCIA
            // =================================================

            currentFile = ""

        } catch (e: Exception) {

            e.printStackTrace()

            recorder?.release()

            recorder = null

            recording = false

            btnRecord.setImageResource(
                R.drawable.mic
            )
        }
    }


    // =========================================================
    // REPRODUZIR ÁUDIO CRIPTOGRAFADO
    // =========================================================

    private fun playAudio(
        path: String
    ) {

        try {

            // =================================================
            // PARAR REPRODUÇÃO ANTERIOR
            // =================================================

            player?.release()

            player = null


            // =================================================
            // APAGAR TEMPORÁRIO ANTERIOR
            // =================================================

            currentTempFile?.let {

                if (it.exists()) {

                    it.delete()
                }
            }

            currentTempFile = null


            // =================================================
            // ARQUIVO CRIPTOGRAFADO
            // =================================================

            val arquivoCriptografado =
                File(path)


            if (!arquivoCriptografado.exists()) {

                return
            }


            // =================================================
            // CRIAR ARQUIVO TEMPORÁRIO
            // =================================================

            val arquivoTemporario =
                File(
                    cacheDir,
                    "audio_${System.currentTimeMillis()}.3gp"
                )


            currentTempFile =
                arquivoTemporario


            // =================================================
            // DESCRIPTOGRAFAR
            // =================================================

            cripto.descriptografarArquivo(
                arquivoCriptografado,
                arquivoTemporario
            )


            // =================================================
            // VERIFICAR TEMPORÁRIO
            // =================================================

            if (!arquivoTemporario.exists()) {

                currentTempFile = null

                return
            }


            // =================================================
            // MEDIA PLAYER
            // =================================================

            player =
                MediaPlayer().apply {

                    setDataSource(
                        arquivoTemporario.absolutePath
                    )

                    prepare()


                    // =========================================
                    // QUANDO TERMINAR
                    // =========================================

                    setOnCompletionListener {

                        release()

                        player = null


                        if (
                            arquivoTemporario.exists()
                        ) {

                            arquivoTemporario.delete()
                        }


                        if (
                            currentTempFile ==
                            arquivoTemporario
                        ) {

                            currentTempFile = null
                        }
                    }


                    start()
                }

        } catch (e: Exception) {

            e.printStackTrace()

            player?.release()

            player = null


            // =================================================
            // APAGAR SOMENTE TEMPORÁRIO
            // =================================================

            currentTempFile?.let {

                if (it.exists()) {

                    it.delete()
                }
            }

            currentTempFile = null
        }
    }


    // =========================================================
    // ADICIONAR GRAVAÇÃO À LISTA
    // =========================================================

    private fun addToList(
        path: String
    ) {

        val file =
            File(path)


        if (!file.exists()) {

            return
        }


        // =====================================================
        // CONTAINER
        // =====================================================

        val container =
            LinearLayout(this)

        container.orientation =
            LinearLayout.HORIZONTAL


        container.setPadding(
            28,
            28,
            28,
            28
        )


        container.setBackgroundResource(
            R.drawable.bg_record_item
        )


        val params =
            LinearLayout.LayoutParams(
                -1,
                -2
            )


        params.setMargins(
            0,
            0,
            0,
            20
        )


        container.layoutParams =
            params


        // =====================================================
        // ÍCONE
        // =====================================================

        val icon =
            ImageView(this)


        icon.setImageResource(
            R.drawable.ic_audio
        )


        icon.layoutParams =
            LinearLayout.LayoutParams(
                60,
                60
            )


        // =====================================================
        // NOME
        // =====================================================

        val text =
            TextView(this)


        // Não mostra ".enc"
        text.text =
            file.nameWithoutExtension


        text.textSize =
            16f


        text.setTextColor(
            Color.WHITE
        )


        text.setPadding(
            24,
            0,
            24,
            0
        )


        text.typeface =
            Typeface.createFromAsset(
                assets,
                "font.ttf"
            )


        text.layoutParams =
            LinearLayout.LayoutParams(
                0,
                -2,
                1f
            )


        // =====================================================
        // EXCLUIR
        // =====================================================

        val delete =
            ImageView(this)


        delete.setImageResource(
            R.drawable.ic_delete
        )


        delete.layoutParams =
            LinearLayout.LayoutParams(
                60,
                60
            )


        delete.setBackgroundColor(
            Color.TRANSPARENT
        )


        // =====================================================
        // ADICIONAR COMPONENTES
        // =====================================================

        container.addView(
            icon
        )


        container.addView(
            text
        )


        container.addView(
            delete
        )


        // =====================================================
        // REPRODUZIR PELO ÍCONE
        // =====================================================

        icon.setOnClickListener {

            playAudio(
                file.absolutePath
            )
        }


        // =====================================================
        // REPRODUZIR PELO NOME
        // =====================================================

        text.setOnClickListener {

            playAudio(
                file.absolutePath
            )
        }


        // =====================================================
        // EXCLUIR
        // =====================================================

        delete.setOnClickListener {

            // ===============================================
            // PARA O PLAYER
            // ===============================================

            player?.release()

            player = null


            // ===============================================
            // APAGA SOMENTE O TEMPORÁRIO
            // ===============================================

            currentTempFile?.let {

                if (it.exists()) {

                    it.delete()
                }
            }

            currentTempFile = null


            // ===============================================
            // APAGA O .ENC
            // ===============================================

            if (file.exists()) {

                file.delete()
            }


            // ===============================================
            // REMOVE DA LISTA
            // ===============================================

            list.removeView(
                container
            )
        }


        // =====================================================
        // ADICIONAR À LISTA
        // =====================================================

        list.addView(
            container
        )
    }


    // =========================================================
    // DESTROY
    // =========================================================

    override fun onDestroy() {

        // =====================================================
        // LIBERAR GRAVADOR
        // =====================================================

        recorder?.release()

        recorder = null


        // =====================================================
        // LIBERAR PLAYER
        // =====================================================

        player?.release()

        player = null


        // =====================================================
        // APAGAR SOMENTE O TEMPORÁRIO DE REPRODUÇÃO
        // =====================================================

        currentTempFile?.let {

            if (it.exists()) {

                it.delete()
            }
        }

        currentTempFile = null


        // =====================================================
        // IMPORTANTE:
        // NÃO APAGA NENHUM .ENC AQUI
        // =====================================================

        super.onDestroy()
    }


    // =========================================================
    // FONTE
    // =========================================================

    private fun aplicarFonte(
        view: View
    ) {

        val fonte =
            try {

                Typeface.createFromAsset(
                    assets,
                    "font.ttf"
                )

            } catch (e: Exception) {

                Typeface.DEFAULT
            }


        if (view is TextView) {

            view.typeface =
                fonte
        }


        if (view is ViewGroup) {

            for (
                i in 0 until view.childCount
            ) {

                aplicarFonte(
                    view.getChildAt(i)
                )
            }
        }
    }


    // =========================================================
    // RESULTADO DA PERMISSÃO
    // =========================================================

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {

        super.onRequestPermissionsResult(
            requestCode,
            permissions,
            grantResults
        )


        if (requestCode == 1) {

            if (
                grantResults.isEmpty() ||
                grantResults[0] !=
                PackageManager.PERMISSION_GRANTED
            ) {

                finish()
            }
        }
    }
}