package com.mulheres

import android.app.Activity
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView

class TiltBrightnessController(
    private val activity: Activity,
    private val sensorManager: SensorManager,
    private val webView: WebView
) : SensorEventListener {

    private var enabled = false
    private var isDark = false

    private var originalBrightness: Float = 1f

    /*
     * Brilho utilizado no modo escuro.
     *
     * 0f = brilho mínimo da janela.
     */
    private var darkBrightness = 0f

    private val gravitySensor: Sensor? =
        sensorManager.getDefaultSensor(
            Sensor.TYPE_GRAVITY
        )

    private val accelerometerSensor: Sensor? =
        sensorManager.getDefaultSensor(
            Sensor.TYPE_ACCELEROMETER
        )

    /*
     * Usa gravidade quando disponível.
     * Caso contrário, usa acelerômetro.
     */
    private val sensor: Sensor?
        get() = gravitySensor ?: accelerometerSensor


    fun start() {

        if (enabled) return

        enabled = true
        isDark = false

        /*
         * Guarda o brilho atual.
         */
        originalBrightness =
            activity.window.attributes.screenBrightness

        /*
         * Alguns aparelhos retornam -1 quando
         * o brilho automático está sendo utilizado.
         */
        if (originalBrightness < 0f) {
            originalBrightness = 1f
        }

        sensor?.let {

            sensorManager.registerListener(
                this,
                it,
                SensorManager.SENSOR_DELAY_NORMAL
            )
        }
    }


    fun setDarkBrightness(value: Float) {

        darkBrightness =
            value.coerceIn(0f, 1f)
    }


    override fun onSensorChanged(
        event: SensorEvent
    ) {

        if (!enabled) return

        val z = event.values[2]

        activity.runOnUiThread {

            /*
             * Celular inclinado para baixo.
             */
            if (z < -8f) {

                if (!isDark) {

                    isDark = true

                    /*
                     * BRILHO = 0%
                     */
                    setBrightness(0f)

                    /*
                     * Esconde as barras usando
                     * o método antigo.
                     */
                    enterFullscreen()

                    /*
                     * Fundo do WebView preto.
                     */
                    webView.setBackgroundColor(
                        Color.BLACK
                    )

                    /*
                     * Torna o conteúdo da página invisível.
                     */
                    webView.evaluateJavascript(
                        """
                        document.documentElement.style.backgroundColor = 'black';
                        document.body.style.backgroundColor = 'black';

                        document.documentElement.style.visibility = 'hidden';
                        document.body.style.visibility = 'hidden';

                        document.documentElement.style.opacity = '0';
                        document.body.style.opacity = '0';
                        """.trimIndent(),
                        null
                    )

                    /*
                     * Avisa o JavaScript que entrou
                     * no modo escuro.
                     */
                    webView.evaluateJavascript(
                        """
                        window.dispatchEvent(
                            new CustomEvent(
                                'tiltbrightness',
                                {
                                    detail: 'dark'
                                }
                            )
                        );
                        """.trimIndent(),
                        null
                    )
                }

            } else {

                /*
                 * Quando o celular volta à posição normal.
                 */
                if (isDark) {

                    isDark = false

                    restoreNormalScreen()

                    /*
                     * Mostra novamente o conteúdo.
                     */
                    webView.evaluateJavascript(
                        """
                        document.documentElement.style.visibility = 'visible';
                        document.body.style.visibility = 'visible';

                        document.documentElement.style.opacity = '1';
                        document.body.style.opacity = '1';
                        """.trimIndent(),
                        null
                    )

                    /*
                     * Avisa o JavaScript que voltou
                     * ao modo normal.
                     */
                    webView.evaluateJavascript(
                        """
                        window.dispatchEvent(
                            new CustomEvent(
                                'tiltbrightness',
                                {
                                    detail: 'normal'
                                }
                            )
                        );
                        """.trimIndent(),
                        null
                    )
                }
            }
        }
    }


    /*
     * Define o brilho da janela.
     */
    private fun setBrightness(
        value: Float
    ) {

        val params =
            activity.window.attributes

        params.screenBrightness =
            value.coerceIn(0f, 1f)

        activity.window.attributes =
            params
    }


    /*
     * FULLSCREEN ANTIGO
     *
     * Não utiliza WindowCompat,
     * WindowInsetsCompat ou
     * WindowInsetsControllerCompat.
     */
    private fun enterFullscreen() {

        activity.window.addFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        activity.window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }


    /*
     * Sai do fullscreen antigo
     * e mostra novamente as barras.
     */
    private fun exitFullscreen() {

        activity.window.clearFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        activity.window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_VISIBLE
    }


    /*
     * Restaura o estado normal da tela.
     */
    private fun restoreNormalScreen() {

        /*
         * Restaura o brilho original.
         */
        val params =
            activity.window.attributes

        params.screenBrightness =
            originalBrightness

        activity.window.attributes =
            params

        /*
         * Mostra novamente as barras.
         */
        exitFullscreen()
    }


    /*
     * Desativa completamente o recurso.
     */
    fun stop() {

        enabled = false
        isDark = false

        sensorManager.unregisterListener(
            this
        )

        activity.runOnUiThread {

            /*
             * Restaura o brilho original.
             */
            val params =
                activity.window.attributes

            params.screenBrightness =
                originalBrightness

            activity.window.attributes =
                params

            /*
             * Mostra as barras.
             */
            exitFullscreen()

            /*
             * Mantém o fundo do WebView preto.
             */
            webView.setBackgroundColor(
                Color.BLACK
            )

            /*
             * Mostra novamente o conteúdo.
             */
            webView.evaluateJavascript(
                """
                document.documentElement.style.visibility = 'visible';
                document.body.style.visibility = 'visible';

                document.documentElement.style.opacity = '1';
                document.body.style.opacity = '1';
                """.trimIndent(),
                null
            )
        }
    }


    override fun onAccuracyChanged(
        sensor: Sensor?,
        accuracy: Int
    ) {
        // Não utilizado.
    }


    /*
     * Interface JavaScript.
     */
    class WebAppInterface(
        private val controller:
            TiltBrightnessController
    ) {

        @JavascriptInterface
        fun startTiltBrightness() {

            controller.start()
        }


        @JavascriptInterface
        fun setDarkBrightness(
            value: Float
        ) {

            controller.setDarkBrightness(
                value
            )
        }


        @JavascriptInterface
        fun stopTiltBrightness() {

            controller.stop()
        }
    }
}